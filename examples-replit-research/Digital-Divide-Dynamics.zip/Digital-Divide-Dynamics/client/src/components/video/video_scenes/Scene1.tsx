import { motion } from 'framer-motion';
import { useEffect, useState, useMemo } from 'react';
import { THEME } from '../theme';

interface Node {
  id: number;
  x: number;
  y: number;
  size: number;
  delay: number;
  glow: number;
}

interface Connection {
  id: string;
  source: Node;
  target: Node;
  delay: number;
}

export function NetworkExplosionScene() {
  const [phase, setPhase] = useState<'initial' | 'expanding' | 'full' | 'contracting'>('initial');

  // Generate deterministic nodes to avoid hydration mismatches
  const { nodes, connections } = useMemo(() => {
    const numNodes = 60;
    const generatedNodes: Node[] = [];
    
    // Central node
    generatedNodes.push({
      id: 0,
      x: 50,
      y: 50,
      size: 15,
      delay: 0,
      glow: 20
    });

    // Generate surrounding nodes in concentric rings
    let idCounter = 1;
    const rings = [
      { count: 6, radius: 15, baseDelay: 0.8 },
      { count: 12, radius: 30, baseDelay: 1.2 },
      { count: 20, radius: 50, baseDelay: 1.6 },
      { count: 21, radius: 75, baseDelay: 2.0 },
    ];

    rings.forEach((ring) => {
      for (let i = 0; i < ring.count; i++) {
        const angle = (i / ring.count) * Math.PI * 2;
        // Add a little deterministic noise to the radius
        const noise = (Math.sin(idCounter * 12.34) * 0.2 + 0.8);
        const r = ring.radius * noise;
        
        generatedNodes.push({
          id: idCounter++,
          x: 50 + Math.cos(angle) * r,
          y: 50 + Math.sin(angle) * r,
          size: 4 + (Math.sin(idCounter * 4.32) * 0.5 + 0.5) * 6,
          delay: ring.baseDelay + (Math.sin(idCounter * 7.89) * 0.2 + 0.2),
          glow: 5 + (Math.sin(idCounter * 1.23) * 0.5 + 0.5) * 10
        });
      }
    });

    // Generate connections
    const generatedConnections: Connection[] = [];
    
    // Connect to center or previous ring
    for (let i = 1; i < generatedNodes.length; i++) {
      const node = generatedNodes[i];
      // Find nearest inner node
      let nearestDist = Infinity;
      let nearestNode = generatedNodes[0];
      
      for (let j = 0; j < i; j++) {
        const candidate = generatedNodes[j];
        const dist = Math.sqrt(Math.pow(node.x - candidate.x, 2) + Math.pow(node.y - candidate.y, 2));
        if (dist < nearestDist) {
          nearestDist = dist;
          nearestNode = candidate;
        }
      }

      generatedConnections.push({
        id: `c-${nearestNode.id}-${node.id}`,
        source: nearestNode,
        target: node,
        delay: node.delay + 0.1
      });

      // Maybe add a cross connection
      if (i > 10 && i % 3 === 0) {
        const crossNode = generatedNodes[i - 4];
        if (crossNode) {
          generatedConnections.push({
            id: `cross-${crossNode.id}-${node.id}`,
            source: crossNode,
            target: node,
            delay: node.delay + 0.3
          });
        }
      }
    }

    return { nodes: generatedNodes, connections: generatedConnections };
  }, []);

  useEffect(() => {
    const timers = [
      setTimeout(() => setPhase('expanding'), 800),
      setTimeout(() => setPhase('full'), 3000),
      setTimeout(() => setPhase('contracting'), 4000), // Start moving to corner
    ];
    return () => timers.forEach(clearTimeout);
  }, []);

  // Animation variants
  const containerVariants = {
    initial: { scale: 1, x: '0%', y: '0%' },
    contracting: { 
      scale: 0.3, 
      x: '-35%', 
      y: '35%'
    }
  };

  return (
    <motion.div 
      className="absolute inset-0 w-full h-full flex items-center justify-center overflow-hidden"
      style={{ backgroundColor: THEME.colors.background }}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.3 }}
    >
      <motion.div 
        className="relative w-[100vw] h-[56.25vw] aspect-video"
        variants={containerVariants}
        animate={phase === 'contracting' ? 'contracting' : 'initial'}
        transition={{ duration: 1.5, ease: 'easeInOut' }}
      >
        {/* Connections */}
        <svg className="absolute inset-0 w-full h-full overflow-hidden">
          {connections.map((conn) => (
            <motion.line
              key={conn.id}
              x1={`${conn.source.x}%`}
              y1={`${conn.source.y}%`}
              x2={`${conn.target.x}%`}
              y2={`${conn.target.y}%`}
              stroke={THEME.colors.white}
              strokeWidth={1.5}
              initial={{ pathLength: 0, opacity: 0 }}
              animate={{ 
                pathLength: phase !== 'initial' ? 1 : 0,
                opacity: phase !== 'initial' ? 0.4 : 0
              }}
              transition={{
                duration: 0.8,
                delay: conn.delay,
                ease: "easeOut"
              }}
            />
          ))}
          
          {/* Highlight pulses along paths */}
          {phase === 'full' && connections.filter((_, i) => i % 5 === 0).map((conn, i) => (
            <motion.circle
              key={`pulse-${conn.id}`}
              r={2}
              fill={THEME.colors.primary}
              initial={{ offsetDistance: "0%", opacity: 0 }}
              animate={{ 
                offsetDistance: ["0%", "100%"],
                opacity: [0, 1, 0]
              }}
              transition={{
                duration: 1.5,
                repeat: Infinity,
                delay: i * 0.2,
                ease: "linear"
              }}
              style={{
                offsetPath: `path('M ${conn.source.x * 12} ${conn.source.y * 8} L ${conn.target.x * 12} ${conn.target.y * 8}')` // Approximate pixel values for motion path
              }}
            />
          ))}
        </svg>

        {/* Nodes */}
        {nodes.map((node) => (
          <motion.div
            key={node.id}
            className="absolute rounded-full z-10"
            style={{
              left: `${node.x}%`,
              top: `${node.y}%`,
              width: node.size,
              height: node.size,
              x: '-50%',
              y: '-50%',
              backgroundColor: node.id === 0 ? THEME.colors.accent : THEME.colors.primary,
              boxShadow: `0 0 ${node.glow}px ${node.id === 0 ? THEME.colors.accent : THEME.colors.primary}`
            }}
            initial={{ scale: 0, opacity: 0 }}
            animate={{ 
              scale: phase !== 'initial' || node.id === 0 ? 1 : 0,
              opacity: 1
            }}
            transition={{
              type: 'spring',
              stiffness: 300,
              damping: 20,
              delay: node.delay
            }}
          >
            {/* Center node pulse */}
            {node.id === 0 && (
              <motion.div
                className="absolute inset-0 rounded-full"
                style={{ border: `2px solid ${THEME.colors.accent}` }}
                animate={{
                  scale: [1, 2.5],
                  opacity: [0.8, 0]
                }}
                transition={{
                  duration: 1.5,
                  repeat: Infinity,
                  ease: "easeOut"
                }}
              />
            )}
          </motion.div>
        ))}

        {/* Cinematic glow background */}
        <motion.div 
          className="absolute inset-0 bg-radial-gradient from-primary/10 to-transparent pointer-events-none"
          initial={{ opacity: 0 }}
          animate={{ opacity: phase === 'full' ? 0.8 : 0 }}
          transition={{ duration: 1.5 }}
          style={{
            background: `radial-gradient(circle at 50% 50%, ${THEME.colors.primary}20 0%, transparent 70%)`
          }}
        />
      </motion.div>
    </motion.div>
  );
}
