import { motion } from 'framer-motion';
import { useEffect, useState, useMemo } from 'react';
import { THEME } from '../theme';

interface Particle {
  id: number;
  x: number;
  y: number;
  targetX: number;
  targetY: number;
  delay: number;
}

export function TimelineMultiplicationScene() {
  const [phase, setPhase] = useState<'initial' | 'timeline-draw' | 'fracturing' | 'multiplying' | 'swarm'>('initial');

  // Generate particles for the "many"
  const particles = useMemo(() => {
    const pts: Particle[] = [];
    // Start with 1 golden circle, which will fracture into 5, which then explode into 200+
    
    // Final swarm positions (right side of timeline)
    for (let i = 0; i < 300; i++) {
      // Create a flocking pattern
      const angle = Math.random() * Math.PI * 2;
      const radius = Math.random() * 25 + 5; // Spread on Y axis mainly
      
      pts.push({
        id: i,
        // Start clustered slightly right of center
        x: 60 + (Math.random() * 5 - 2.5),
        y: 50 + (Math.random() * 10 - 5),
        // Target: spread out towards the right
        targetX: 75 + Math.cos(angle) * (radius * 0.4) + (Math.random() * 20),
        targetY: 50 + Math.sin(angle) * radius,
        delay: Math.random() * 1.5 // Staggered explosion
      });
    }
    return pts;
  }, []);

  useEffect(() => {
    const timers = [
      setTimeout(() => setPhase('timeline-draw'), 500),
      setTimeout(() => setPhase('fracturing'), 1500),
      setTimeout(() => setPhase('multiplying'), 2500),
      setTimeout(() => setPhase('swarm'), 3500),
    ];
    return () => timers.forEach(clearTimeout);
  }, []);

  return (
    <motion.div 
      className="absolute inset-0 w-full h-full overflow-hidden"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.3 }}
    >
      {/* Timeline Axis */}
      <motion.div
        className="absolute top-1/2 left-0 h-[2px] w-full origin-left"
        style={{ backgroundColor: THEME.colors.white, opacity: 0.3 }}
        initial={{ scaleX: 0 }}
        animate={{ scaleX: phase !== 'initial' ? 1 : 0 }}
        transition={{ duration: 1.5, ease: [0.16, 1, 0.3, 1] }}
      />
      
      {/* Timeline Markers */}
      {[20, 40, 60, 80].map((pos, i) => (
        <motion.div
          key={`marker-${i}`}
          className="absolute top-1/2 w-[2px] h-4 -translate-y-1/2"
          style={{ left: `${pos}%`, backgroundColor: THEME.colors.white, opacity: 0.5 }}
          initial={{ scaleY: 0 }}
          animate={{ scaleY: phase !== 'initial' ? 1 : 0 }}
          transition={{ duration: 0.5, delay: 0.5 + (i * 0.2) }}
        />
      ))}

      {/* The "Few" (Golden Circle initially on left) */}
      <motion.div
        className="absolute top-1/2 left-[20%] w-12 h-12 -translate-x-1/2 -translate-y-1/2 rounded-full z-20 flex items-center justify-center"
        style={{ 
          backgroundColor: THEME.colors.accent,
          boxShadow: `0 0 30px ${THEME.colors.accent}80`
        }}
        initial={{ scale: 0, opacity: 0 }}
        animate={{ 
          scale: phase === 'initial' ? 0 : (phase === 'timeline-draw' ? 1 : 0),
          opacity: phase === 'timeline-draw' ? 1 : 0,
          x: phase === 'fracturing' ? '150%' : '-50%' // move right before fracturing
        }}
        transition={{ 
          scale: { type: 'spring', bounce: 0.5 },
          x: { duration: 1, ease: "easeInOut" },
          opacity: { duration: 0.2 }
        }}
      />

      {/* First Fracture (5 golden nodes) */}
      {phase !== 'initial' && phase !== 'timeline-draw' && (
        <>
          {[...Array(5)].map((_, i) => {
            const angle = (i / 5) * Math.PI * 2;
            return (
              <motion.div
                key={`frac-${i}`}
                className="absolute top-1/2 left-[40%] w-6 h-6 -translate-x-1/2 -translate-y-1/2 rounded-full z-20"
                style={{ backgroundColor: THEME.colors.accent }}
                initial={{ x: '-50%', y: '-50%', scale: 1, opacity: 1 }}
                animate={
                  phase === 'fracturing' ? {
                    x: `calc(-50% + ${Math.cos(angle) * 40}px)`,
                    y: `calc(-50% + ${Math.sin(angle) * 40}px)`,
                    scale: 1,
                  } : {
                    x: `calc(-50% + ${Math.cos(angle) * 100}px + 20vw)`,
                    y: `calc(-50% + ${Math.sin(angle) * 100}px)`,
                    scale: 0,
                    opacity: 0
                  }
                }
                transition={{ duration: 0.8, ease: "easeOut" }}
              />
            );
          })}
        </>
      )}

      {/* The "Many" (Swarm of electric blue dots) */}
      {(phase === 'multiplying' || phase === 'swarm') && (
        <div className="absolute inset-0 z-10">
          {particles.map((p) => (
            <motion.div
              key={`p-${p.id}`}
              className="absolute w-2 h-2 rounded-full"
              style={{ backgroundColor: THEME.colors.primary }}
              initial={{ 
                left: `${p.x}%`, 
                top: `${p.y}%`,
                scale: 0,
                opacity: 0
              }}
              animate={{
                left: `${p.targetX}%`,
                top: `${p.targetY}%`,
                scale: Math.random() * 0.5 + 0.5, // Random sizes
                opacity: Math.random() * 0.6 + 0.4,
              }}
              transition={{
                duration: 1.5 + Math.random(),
                delay: p.delay,
                ease: [0.16, 1, 0.3, 1]
              }}
            />
          ))}
        </div>
      )}

      {/* Typography Overlay */}
      <motion.div 
        className="absolute z-30"
        style={{ bottom: '5vh', left: '5vw' }}
        initial={{ opacity: 0, y: '2vh' }}
        animate={{ opacity: phase === 'swarm' ? 1 : 0, y: phase === 'swarm' ? '0vh' : '2vh' }}
        transition={{ duration: 0.8, delay: 0.5 }}
      >
        <h1 
          className="font-bold tracking-tight mb-[1vh]"
          style={{ 
            color: THEME.colors.white, 
            fontFamily: THEME.fonts.display,
            fontSize: 'clamp(1.5rem, 4vw, 3.5rem)'
          }}
        >
          Exclusive to Ubiquitous
        </h1>
        <p 
          className="text-slate-300"
          style={{ 
            fontFamily: THEME.fonts.body, 
            color: THEME.colors.text,
            fontSize: 'clamp(0.875rem, 1.5vw, 1.25rem)',
            maxWidth: '45vw'
          }}
        >
          Technology fragments centralized power into decentralized access.
        </p>
      </motion.div>
    </motion.div>
  );
}
