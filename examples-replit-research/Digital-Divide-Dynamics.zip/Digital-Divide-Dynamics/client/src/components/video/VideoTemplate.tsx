// Video Template - Main Entry Point
import { AnimatePresence } from 'framer-motion';
import { useVideoPlayer } from '@/lib/video';
import { THEME } from './theme';
import { NetworkExplosionScene } from './video_scenes/Scene1';
import { TimelineMultiplicationScene } from './video_scenes/Scene2';

// 12 seconds total: 5 seconds network, 7 seconds timeline
const SCENE_DURATIONS = {
  network: 5000,
  timeline: 7000,
};

export default function VideoTemplate() {
  const { currentScene } = useVideoPlayer({
    durations: SCENE_DURATIONS,
  });

  return (
    <div
      className="w-full h-full overflow-hidden relative aspect-video"
      style={{ backgroundColor: THEME.colors.background }}
    >
      <AnimatePresence mode="sync">
        {currentScene === 0 && <NetworkExplosionScene key="network" />}
        {currentScene === 1 && <TimelineMultiplicationScene key="timeline" />}
      </AnimatePresence>
    </div>
  );
}
