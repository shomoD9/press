export const THEME = {
  colors: {
    background: '#0A1128',
    primary: '#00D9FF', // Electric blue
    accent: '#FFD700', // Gold
    white: '#FFFFFF',
    text: '#E2E8F0' // Slate-200 for readability
  },
  fonts: {
    display: "'Space Grotesk', sans-serif",
    body: "'DM Sans', sans-serif"
  }
};
