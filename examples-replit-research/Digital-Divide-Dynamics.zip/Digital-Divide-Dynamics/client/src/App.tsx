import VideoTemplate from "@/components/video/VideoTemplate";

export default function App() {
  return <VideoTemplate />;
}
