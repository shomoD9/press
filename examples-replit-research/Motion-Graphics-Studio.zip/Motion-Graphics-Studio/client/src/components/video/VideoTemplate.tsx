import { AnimatePresence } from 'framer-motion';
import { useVideoPlayer } from '@/lib/video';
import { IntroScene } from './video_scenes/IntroScene';
import { TrendScene } from './video_scenes/TrendScene';
import { FlawScene } from './video_scenes/FlawScene';
import { AutotelicScene } from './video_scenes/AutotelicScene';
import { DatFrameworkScene } from './video_scenes/DatFrameworkScene';
import { TraitsScene } from './video_scenes/TraitsScene';
import { TruthScene } from './video_scenes/TruthScene';
import { ConclusionScene } from './video_scenes/ConclusionScene';
import audioFile from '@assets/The_Real_Reason_You_Can\'t_Gamify_Your_Life_-_Armchair_Descendi_1772179348701.mp3';

const SCENE_DURATIONS = {
  intro: 15000,
  trend: 28000,
  flaw: 18000,
  autotelic: 22000,
  dat: 55000,
  traits: 62000,
  truth: 45000,
  conclusion: 152848,
};

export default function VideoTemplate() {
  const { currentScene } = useVideoPlayer({
    durations: SCENE_DURATIONS,
  });

  return (
    <div
      className="w-full h-screen overflow-hidden relative"
      style={{ backgroundColor: 'var(--color-bg-light)' }}
    >
      <audio src={audioFile} autoPlay />

      <AnimatePresence mode="wait">
        {currentScene === 0 && <IntroScene key="intro" />}
        {currentScene === 1 && <TrendScene key="trend" />}
        {currentScene === 2 && <FlawScene key="flaw" />}
        {currentScene === 3 && <AutotelicScene key="autotelic" />}
        {currentScene === 4 && <DatFrameworkScene key="dat" />}
        {currentScene === 5 && <TraitsScene key="traits" />}
        {currentScene === 6 && <TruthScene key="truth" />}
        {currentScene === 7 && <ConclusionScene key="conclusion" />}
      </AnimatePresence>
    </div>
  );
}