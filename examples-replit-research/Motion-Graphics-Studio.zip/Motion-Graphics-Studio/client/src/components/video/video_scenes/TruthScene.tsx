import { motion } from 'framer-motion';
import { sceneTransitions } from '@/lib/video';
import appsImg from '@/assets/images/apps.png';

export function TruthScene() {
  return (
    <motion.div
      className="absolute inset-0 w-full h-full flex flex-col items-center justify-center bg-[var(--color-bg-dark)] text-white overflow-hidden"
      {...sceneTransitions.perspectiveFlip}
    >
      <motion.div
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 1 }}
        className="relative"
        style={{ width: 'clamp(300px, 70vw, 90vh)', height: 'clamp(200px, 70vh, 90vh)' }}
      >
        <img src={appsImg} className="w-full h-full object-cover vox-border" />
        
        <motion.div 
          className="absolute inset-0 bg-black/60 flex items-center justify-center"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 2, duration: 1 }}
        >
          <h2 className="font-display font-black text-center uppercase bg-[var(--color-accent-2)] vox-border" style={{ fontSize: 'clamp(36px, 5vw, 80px)', padding: 'clamp(1rem, 3vh, 2rem)' }}>
            You cannot gamify<br/>
            something that is not<br/>
            a game.
          </h2>
        </motion.div>
      </motion.div>
    </motion.div>
  );
}