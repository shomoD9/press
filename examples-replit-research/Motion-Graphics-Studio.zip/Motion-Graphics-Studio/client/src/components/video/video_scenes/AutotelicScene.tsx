import { motion } from 'framer-motion';
import { sceneTransitions } from '@/lib/video';
import dishesImg from '@/assets/images/dishes.png';

export function AutotelicScene() {
  return (
    <motion.div
      className="absolute inset-0 w-full h-full flex flex-col items-center justify-center bg-[var(--color-bg-light)] overflow-hidden vox-grid"
      {...sceneTransitions.splitHorizontal}
    >
      <motion.div className="absolute flex gap-[2vw] z-20" style={{ top: 'clamp(1rem, 4vh, 3rem)' }}>
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1 }}
          className="font-mono bg-black text-white px-6 py-2 vox-border"
          style={{ fontSize: 'clamp(18px, 2vw, 32px)' }}
        >
          AUTOTELIC
        </motion.div>
        <div className="font-mono py-2" style={{ fontSize: 'clamp(18px, 2vw, 32px)' }}>VS</div>
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 5 }}
          className="font-mono bg-[var(--color-accent-2)] text-white px-6 py-2 vox-border"
          style={{ fontSize: 'clamp(18px, 2vw, 32px)' }}
        >
          INSTRUMENTAL
        </motion.div>
      </motion.div>

      <motion.img 
        src={dishesImg}
        initial={{ scale: 0, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ delay: 7, type: "spring", bounce: 0.5 }}
        className="w-[50vw] max-w-[70vh] object-cover vox-border z-10"
        style={{ marginTop: 'clamp(1rem, 4vh, 2rem)' }}
      />
    </motion.div>
  );
}