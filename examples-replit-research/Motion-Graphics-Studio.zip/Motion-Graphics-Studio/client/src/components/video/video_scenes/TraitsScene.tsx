import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { sceneTransitions } from '@/lib/video';
import { useSceneTimer } from '@/lib/video/hooks';

export function TraitsScene() {
  const [step, setStep] = useState(0);

  useSceneTimer([
    { time: 10000, callback: () => setStep(1) },
    { time: 15000, callback: () => setStep(2) },
    { time: 21000, callback: () => setStep(3) },
    { time: 35000, callback: () => setStep(4) },
  ]);

  return (
    <motion.div
      className="absolute inset-0 w-full h-full flex items-center justify-center bg-[var(--color-bg-light)] text-black overflow-hidden vox-grid"
      {...sceneTransitions.zoomThrough}
    >
      <AnimatePresence mode="wait">
        {step < 4 && (
          <motion.div 
            key="traits-grid"
            className="w-full flex justify-between items-center"
            style={{ paddingLeft: 'max(1.5rem, 3vw)', paddingRight: 'max(1.5rem, 3vw)' }}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <motion.div 
              className="flex-1 text-center border-r-8 border-black last:border-r-0 px-4"
              animate={{ scale: step === 1 ? 1.2 : 1, opacity: step >= 1 ? 1 : 0.3 }}
            >
              <div style={{ fontSize: 'clamp(60px, 10vw, 120px)', marginBottom: 'clamp(0.5rem, 2vh, 1rem)' }}>🎮</div>
              <h3 className="font-display font-black uppercase" style={{ fontSize: 'clamp(30px, 4vw, 60px)' }}>Autonomy</h3>
            </motion.div>
            <motion.div 
              className="flex-1 text-center border-r-8 border-black last:border-r-0 px-4"
              animate={{ scale: step === 2 ? 1.2 : 1, opacity: step >= 2 ? 1 : 0.3 }}
            >
              <div style={{ fontSize: 'clamp(60px, 10vw, 120px)', marginBottom: 'clamp(0.5rem, 2vh, 1rem)' }}>🎲</div>
              <h3 className="font-display font-black uppercase" style={{ fontSize: 'clamp(30px, 4vw, 60px)' }}>Uncertainty</h3>
            </motion.div>
            <motion.div 
              className="flex-1 text-center px-4"
              animate={{ scale: step === 3 ? 1.2 : 1, opacity: step >= 3 ? 1 : 0.3 }}
            >
              <div style={{ fontSize: 'clamp(60px, 10vw, 120px)', marginBottom: 'clamp(0.5rem, 2vh, 1rem)' }}>📈</div>
              <h3 className="font-display font-black uppercase" style={{ fontSize: 'clamp(30px, 4vw, 60px)' }}>Competence</h3>
            </motion.div>
          </motion.div>
        )}

        {step >= 4 && (
          <motion.div 
            key="highest-performers"
            className="absolute inset-0 bg-[var(--color-accent)] flex items-center justify-center flex-col z-50"
            initial={{ clipPath: 'circle(0% at 50% 50%)' }}
            animate={{ clipPath: 'circle(150% at 50% 50%)' }}
            transition={{ duration: 1, ease: "easeInOut" }}
          >
            <h2 className="font-display font-black text-center uppercase" style={{ fontSize: 'clamp(60px, 12vw, 150px)', lineHeight: '0.85' }}>
              <span className="text-white drop-shadow-[4px_4px_0_#000]">HIGHEST</span><br/>
              PERFORMERS
            </h2>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}