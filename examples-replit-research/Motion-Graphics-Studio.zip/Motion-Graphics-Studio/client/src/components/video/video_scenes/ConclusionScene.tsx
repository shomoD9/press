import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { sceneTransitions } from '@/lib/video';
import { useSceneTimer } from '@/lib/video/hooks';
import mountainImg from '@/assets/images/mountain.png';

export function ConclusionScene() {
  const [step, setStep] = useState(0);

  useSceneTimer([
    { time: 20000, callback: () => setStep(1) },
    { time: 40000, callback: () => setStep(2) },
    { time: 70000, callback: () => setStep(3) },
  ]);

  return (
    <motion.div
      className="absolute inset-0 w-full h-full flex flex-col bg-[var(--color-bg-light)] overflow-hidden"
      {...sceneTransitions.fadeBlur}
    >
      <div className="absolute inset-0 w-full h-full flex items-center justify-center" style={{ padding: 'max(1.5rem, 4vh)' }}>
        <AnimatePresence mode="wait">
          {step === 0 && (
            <motion.h2 
              key="step0"
              className="font-display font-black text-center uppercase"
              style={{ fontSize: 'clamp(40px, 7vw, 90px)', lineHeight: '1.2' }}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
            >
              We used it to <span className="text-[var(--color-accent-2)] underline" style={{ textDecorationColor: 'var(--color-accent)', textDecorationThickness: '0.15em', textUnderlineOffset: '0.2em' }}>lie to ourselves</span><br/>
              about what we wanted.
            </motion.h2>
          )}

          {step === 1 && (
            <motion.div 
              key="step1"
              className="w-full h-full flex items-center justify-center relative"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
            >
              <img src={mountainImg} className="vox-border shadow-2xl object-cover" style={{ maxWidth: '80%', maxHeight: '80%' }} />
              <div className="absolute bg-black text-white font-mono vox-border" style={{ bottom: 'max(1.5rem, 3vh)', right: 'max(1.5rem, 3vw)', padding: 'clamp(0.75rem, 1.5vh, 1.5rem)', fontSize: 'clamp(18px, 2.5vw, 40px)' }}>
                GENUINE INTEREST
              </div>
            </motion.div>
          )}

          {step >= 2 && (
            <motion.div 
              key="step2"
              className="w-full h-full flex flex-col items-center justify-center"
              style={{ gap: 'clamp(1.5rem, 3vh, 2rem)' }}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 1 }}
            >
              <h1 className="font-display font-black text-center uppercase" style={{ fontSize: 'clamp(50px, 10vw, 130px)', lineHeight: '0.85' }}>
                Stop <br/><span className="bg-[var(--color-accent)] vox-border" style={{ paddingLeft: '0.5em', paddingRight: '0.5em' }}>Tricking</span><br/> Yourself.
              </h1>
              {step >= 3 && (
                <motion.div 
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="font-mono text-[var(--color-text-secondary)] border-t-4 border-black pt-8"
                  style={{ marginTop: 'clamp(1rem, 2vh, 1.5rem)', fontSize: 'clamp(16px, 2vw, 32px)' }}
                >
                  Thanks for watching.
                </motion.div>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </motion.div>
  );
}