import { useState } from 'react';
import { motion } from 'framer-motion';
import { sceneTransitions } from '@/lib/video';
import { useSceneTimer } from '@/lib/video/hooks';

export function DatFrameworkScene() {
  const [step, setStep] = useState(0);

  useSceneTimer([
    { time: 6000, callback: () => setStep(1) }, 
    { time: 14000, callback: () => setStep(2) }, 
    { time: 24000, callback: () => setStep(3) }, 
  ]);

  return (
    <motion.div
      className="absolute inset-0 w-full h-full flex flex-col justify-center bg-[var(--color-primary)] text-[var(--color-bg-light)] overflow-hidden vox-grid-dark"
      style={{ paddingLeft: 'max(1.5rem, 5vw)', paddingRight: 'max(1.5rem, 5vw)' }}
      {...sceneTransitions.wipe}
    >
      <motion.h2 
        className="font-mono text-[var(--color-accent)] mb-[3vh]"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.5 }}
        style={{ fontSize: 'clamp(36px, 4vw, 60px)', marginBottom: 'clamp(1.5rem, 3vh, 2rem)' }}
      >
        THE D.A.T. FRAMEWORK
      </motion.h2>

      <div className="flex flex-col gap-[2vh]">
        <motion.div 
          className="flex items-center gap-[2vw]"
          initial={{ opacity: 0, x: -50 }}
          animate={{ opacity: step >= 1 ? 1 : 0.2, x: step >= 1 ? 0 : -50 }}
        >
          <div className="font-display font-black bg-[var(--color-accent)] text-black flex items-center justify-center vox-border flex-shrink-0" style={{ width: 'clamp(100px, 10vw, 130px)', height: 'clamp(100px, 10vw, 130px)', fontSize: 'clamp(50px, 7vw, 100px)' }}>D</div>
          <div className="font-display font-bold" style={{ fontSize: 'clamp(40px, 6vw, 90px)' }}>DISTRACT</div>
        </motion.div>

        <motion.div 
          className="flex items-center gap-[2vw]"
          initial={{ opacity: 0, x: -50 }}
          animate={{ opacity: step >= 2 ? 1 : 0.2, x: step >= 2 ? 0 : -50 }}
        >
          <div className="font-display font-black bg-[var(--color-accent-2)] text-white flex items-center justify-center vox-border flex-shrink-0" style={{ width: 'clamp(100px, 10vw, 130px)', height: 'clamp(100px, 10vw, 130px)', fontSize: 'clamp(50px, 7vw, 100px)' }}>A</div>
          <div className="font-display font-bold" style={{ fontSize: 'clamp(40px, 6vw, 90px)' }}>AUTOMATE</div>
        </motion.div>

        <motion.div 
          className="flex items-center gap-[2vw]"
          initial={{ opacity: 0, x: -50 }}
          animate={{ opacity: step >= 3 ? 1 : 0.2, x: step >= 3 ? 0 : -50 }}
        >
          <div className="font-display font-black bg-white text-black flex items-center justify-center vox-border flex-shrink-0" style={{ width: 'clamp(100px, 10vw, 130px)', height: 'clamp(100px, 10vw, 130px)', fontSize: 'clamp(50px, 7vw, 100px)' }}>T</div>
          <div className="font-display font-bold" style={{ fontSize: 'clamp(40px, 6vw, 90px)' }}>DELEGATE</div>
        </motion.div>
      </div>
    </motion.div>
  );
}