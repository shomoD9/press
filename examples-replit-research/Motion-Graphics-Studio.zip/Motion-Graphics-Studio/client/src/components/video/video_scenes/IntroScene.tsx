import { motion } from 'framer-motion';
import { sceneTransitions } from '@/lib/video';
import gamificationImg from '@/assets/images/gamification.png';

export function IntroScene() {
  return (
    <motion.div
      className="absolute inset-0 w-full h-full flex flex-col items-center justify-center bg-[var(--color-bg-light)] overflow-hidden vox-grid"
      {...sceneTransitions.wipe}
    >
      <motion.div
        initial={{ y: 50, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 1, duration: 0.8, ease: "easeOut" }}
        className="font-display font-black leading-none text-center z-10 uppercase tracking-tighter mix-blend-difference"
        style={{ fontSize: 'clamp(60px, 8vw, 120px)' }}
      >
        GAMIFY<br />YOUR<br />LIFE?
      </motion.div>

      <motion.img 
        src={gamificationImg}
        initial={{ scale: 0.8, opacity: 0, y: 100, rotate: -5 }}
        animate={{ scale: 1, opacity: 1, y: 0, rotate: 0 }}
        transition={{ delay: 2, type: "spring", stiffness: 100, damping: 20 }}
        className="absolute w-[60vh] max-w-[80vw] vox-border object-cover aspect-video z-0 shadow-2xl"
        style={{ bottom: 'clamp(-5%, -10%, 5%)', transformOrigin: 'bottom center' }}
      />
      
      <motion.div 
        className="absolute top-[2vh] left-[2vh] font-mono uppercase bg-[var(--color-accent)] px-4 py-2 font-bold vox-border"
        initial={{ x: -100, opacity: 0 }}
        animate={{ x: 0, opacity: 1 }}
        transition={{ delay: 0.5, type: "spring" }}
        style={{ fontSize: 'clamp(14px, 1.5vw, 20px)' }}
      >
        The Premise
      </motion.div>
    </motion.div>
  );
}