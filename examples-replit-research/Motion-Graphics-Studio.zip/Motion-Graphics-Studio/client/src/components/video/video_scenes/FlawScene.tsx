import { motion } from 'framer-motion';
import { sceneTransitions } from '@/lib/video';
import rockCarImg from '@/assets/images/rock_car.png';

export function FlawScene() {
  return (
    <motion.div
      className="absolute inset-0 w-full h-full flex flex-row items-center justify-between bg-[var(--color-accent)] text-black overflow-hidden"
      style={{ paddingLeft: 'max(1.5rem, 5vw)', paddingRight: 'max(1.5rem, 5vw)' }}
      {...sceneTransitions.slideUp}
    >
      <div className="w-1/2 flex flex-col z-10 pr-[2vw]">
        <motion.h2 
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5, duration: 0.6 }}
          className="font-display font-black uppercase leading-tight"
          style={{ fontSize: 'clamp(40px, 5.5vw, 80px)' }}
        >
          MISTAKING THE <span className="bg-white px-4 vox-border block w-max mt-4">BONNET</span> FOR THE <span className="bg-black text-white px-4 vox-border block w-max mt-4">ENGINE</span>
        </motion.h2>
      </div>

      <motion.div className="w-1/2 relative" style={{ height: 'clamp(300px, 80vh, 90vh)' }}>
        <motion.img 
          src={rockCarImg}
          initial={{ x: 200, opacity: 0, rotate: 10 }}
          animate={{ x: 0, opacity: 1, rotate: -5 }}
          transition={{ delay: 1.5, type: "spring", stiffness: 100, damping: 20 }}
          className="absolute inset-0 w-full h-full object-cover vox-border shadow-2xl"
        />
      </motion.div>
    </motion.div>
  );
}