import { motion } from 'framer-motion';
import { sceneTransitions } from '@/lib/video';

export function TrendScene() {
  return (
    <motion.div
      className="absolute inset-0 w-full h-full flex flex-col justify-center bg-[var(--color-bg-dark)] text-white overflow-hidden vox-grid-dark"
      style={{ paddingLeft: 'max(1.5rem, 5vw)', paddingRight: 'max(1.5rem, 5vw)' }}
      {...sceneTransitions.clipPolygon}
    >
      <motion.div
        initial={{ x: -100, opacity: 0 }}
        animate={{ x: 0, opacity: 1 }}
        transition={{ delay: 0.5, duration: 0.8, ease: "circOut" }}
        className="font-display font-black leading-none uppercase tracking-tighter"
        style={{ fontSize: 'clamp(80px, 12vw, 180px)' }}
      >
        <span className="text-[var(--color-accent)]">2017:</span><br />
        THE HYPE
      </motion.div>

      <motion.div
        initial={{ y: 50, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 3, duration: 0.8, ease: "circOut" }}
        className="mt-[3vh] font-mono text-[var(--color-accent-2)]"
        style={{ fontSize: 'clamp(20px, 2.5vw, 32px)', marginTop: 'clamp(2rem, 3vh, 4rem)' }}
      >
        WHAT WENT WRONG?
      </motion.div>

      <motion.div 
        className="absolute border-[0.5vw] border-[var(--color-accent)] rounded-full"
        animate={{ rotate: 360, scale: [1, 1.1, 1] }}
        transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
        style={{ 
          right: 'max(1.5rem, 5vw)',
          top: 'max(1.5rem, 5vh)',
          width: 'clamp(200px, 20vw, 300px)',
          height: 'clamp(200px, 20vw, 300px)'
        }}
      />
    </motion.div>
  );
}